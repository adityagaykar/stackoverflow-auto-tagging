package sem2.smai.project.src;

import java.util.Set;

public class PostPOJO {
	private Set<String> tags;
	private Set<String> bodyTokens;
	public Set<String> getTags() {
		return tags;
	}
	public void setTags(Set<String> tags) {
		this.tags = tags;
	}
	public Set<String> getBodyTokens() {
		return bodyTokens;
	}
	public void setBodyTokens(Set<String> bodyTokens) {
		this.bodyTokens = bodyTokens;
	}
	
			
}

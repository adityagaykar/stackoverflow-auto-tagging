python demo_naivebayes.py prior.in likelihood.in

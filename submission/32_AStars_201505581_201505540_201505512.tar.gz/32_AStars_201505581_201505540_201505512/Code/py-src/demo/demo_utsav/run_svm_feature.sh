python demo_svm_feature_extractor.py likelihood.in 1000_tagfreq.in title-body-tag-10000.out 2000
